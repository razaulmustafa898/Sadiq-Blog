import React from 'react'
import BlogEditor_Button from '../BlogEditor_Button';

const BlogEditor_Button2 = () => {
    return (
        <>
            <BlogEditor_Button buttonTitle="Create post" bgColorStyle=" bg-blue-500 hover:bg-blue-700" />
        </>
    )
}

export default BlogEditor_Button2;