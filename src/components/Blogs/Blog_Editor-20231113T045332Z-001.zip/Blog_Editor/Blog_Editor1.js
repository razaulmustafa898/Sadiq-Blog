import React, { useState } from 'react';

const Blog_Editor1 = () => {
    const [blogEditor, setblogEditor] = useState("");
    return (
        <>
            <div className="blog_editor1">

            </div>
        </>
    )
}

export default Blog_Editor1;