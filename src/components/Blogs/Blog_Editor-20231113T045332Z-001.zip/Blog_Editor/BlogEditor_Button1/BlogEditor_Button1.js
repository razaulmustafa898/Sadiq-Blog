import React from 'react'
import BlogEditor_Button from '../BlogEditor_Button'

const BlogEditor_Button1 = () => {
  return (
        <>
        <BlogEditor_Button buttonTitle="Rest Content" bgColorStyle=" bg-red-500 hover:bg-red-700"/>
        </>
  )
}

export default BlogEditor_Button1
