import React from 'react'
import BlogPost_Title from './BlogPost_Title'

const BlogPost_Title1 = () => {
    return (
        <>
            <BlogPost_Title postTitle="Post title" />
        </>
    )
}

export default BlogPost_Title1;