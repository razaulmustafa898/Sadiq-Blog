import React from 'react'
import BlogPost_Title from './BlogPost_Title'

const BlogPost_Title3 = () => {
    return (
        <>
            <BlogPost_Title postTitle="Post Category" />
        </>
    )
}

export default BlogPost_Title3;