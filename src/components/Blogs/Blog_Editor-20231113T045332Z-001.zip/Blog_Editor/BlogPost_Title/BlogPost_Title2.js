import React from 'react'
import BlogPost_Title from './BlogPost_Title'

const BlogPost_Title2 = () => {
    return (
        <>
            <BlogPost_Title postTitle="Post Content" />
        </>
    )
}

export default BlogPost_Title2;